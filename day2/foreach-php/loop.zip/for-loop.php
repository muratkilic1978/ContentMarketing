<!DOCTYPE html>
<html>
<body>

<?php 
for ($x = 0; $x <= 100; $x=$x+2) {
    echo "All even numbers from 1 to 100 : $x <br>";
} 
?>


</body>
</html>