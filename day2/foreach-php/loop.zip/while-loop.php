<!DOCTYPE html>
<html>
<body>

<?php 
$x = 1;
  
while($x <= 10) {
   echo "The number is: $x <br>";
   $x++;
} 
?>   

</body>
</html>