<!DOCTYPE html>
<html>
<body>

<?php 
$income = array('january' => 14000, 'february' => 150000, 'march' => 13500, 'april' => 16000, 'May' => 14600, 'June' => 16400); 

foreach ($income as $key => $value) 
{
   echo "<dt>$key<dd>$value <br>";

}
?>   

</body>
</html>