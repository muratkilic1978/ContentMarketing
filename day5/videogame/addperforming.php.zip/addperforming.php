<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="utf-8">
  <title>Add perform to perform-table</title>
    <!---
      * CSS files that are included
      * 
      *
    -->
    <!-- Latest AweSome Font CSS -->
    <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/font-awesome/4.4.0/css/font-awesome.min.css">

    <!-- Latest Bootstrap compiled and minified CSS -->
    <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.5/css/bootstrap.min.css">
      
    <!-- Optional Bootstrap theme -->
    <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.5/css/bootstrap-theme.min.css">
      
    <!-- jQuery CSS  -->
    <link rel="stylesheet" href="https://code.jquery.com/ui/1.11.4/themes/smoothness/jquery-ui.css">

    <!-- Font Awesome -->
    <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/font-awesome/4.4.0/css/font-awesome.min.css">

    <link rel="stylesheet" href="css/style.css">

<!--
 * JavaScript files that are included
 * 
 * 
-->

    <!-- jQuery -->
    <script src="https://code.jquery.com/jquery-1.11.3.min.js"></script>
      
    <!-- jQuery UI -->
    <script src="https://code.jquery.com/ui/1.11.4/jquery-ui.js"></script>
      
    <!-- Latest compiled and minified Bootstrap JavaScript -->
    <script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.5/js/bootstrap.min.js"></script>

  
</head>
<body>
  <div class="wrap">
    <div class="container">
      <i class="fa fa-calendar fa-4x"></i>
      <div class="page-header">
        <h1>Add perform. <small>Please enter day as yyyy-mm-dd and time as hh-mm-ss and select artist and stage.</small></h1>
      </div>
      
      <form method="post" action="addingperforming.php">
        
        <div class="form-group">
          <label for="datename">Date:</label>
          <input type="text" name="datename" class="form-control" id="datename" placeholder="YYYY-MM-DD">
        </div>
        
        <div class="form-group">
          <label for="timename">Time</label>
          <input type="text" name="timename" class="form-control" id="timename" placeholder="HH-MM-SS">
        </div>
        
        <?php

        # Include database connection-file - connectdb.php
        include('includes/connectdb.php');
        
        # Make a sql-query to the database
        $artistQuery = "SELECT id, name FROM artist";

        #Perform queries against the database:
        $resultArtist = mysqli_query($dbc, $artistQuery);

        # Make a sql-query to the database
        $stageQuery = "SELECT id, colorname FROM stage";

        #Perform queries against the database:
        $resultStage = mysqli_query($dbc, $stageQuery);

          
        ?>
        
        <div class="form-group">
          <label for="artistname">Artist name:</label>
          <select name="artistid">
            <!-- iterate through the WHILE LOOP  -->
            <?php while($row = mysqli_fetch_array($resultArtist)): ?>
              <!-- Echo out values {id} and {name}   -->
              <option value=" <?php echo $row['id']; ?> "><?php echo $row['name']; ?></option>
            <?php endwhile; ?>
          </select>
         </div>
         
         <div class="form-group">
          <label for="stagename">Stage name:</label>
           <select name="stageid">
            <?php while($row = mysqli_fetch_array($resultStage)): ?>
              <option value=" <?php echo $row['id']; ?> "><?php echo $row['colorname']; ?></option>
            <?php endwhile; ?>
          </select>
        </div>
      
      
        <input type="submit" name="Submit" value="Submit" class="btn btn-default"/>
      </form>
      <aside>
        <img src="images/band.png" width="261" height="350" alt="band" style="float:right">
      </aside>
    </div> <!-- END CONTAINER -->
  </div> <!-- END WRAP -->

</body>
</html>
